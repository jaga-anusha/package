package Day10HW;

public class Thread {
	public static void main(String[] args) {
		 Runner r =new Runner();
		 
	//	Thread t1 = new Thread(r,"t1");
		
		
		
	}

}
class Runner implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		
	}
	
}