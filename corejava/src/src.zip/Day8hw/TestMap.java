package Day8hw;

import java.util.TreeMap;

public class TestMap {

	public static void main(String[] args) {
		
		TreeMap<Integer,String> studentsmap = new TreeMap<Integer,String>();
		
		studentsmap.put(3, "sasi");
		studentsmap.put(2, "jasi");
		studentsmap.put(4, "lasi");
		studentsmap.put(1, "masi");
		System.out.println(studentsmap);
		
	}
}
