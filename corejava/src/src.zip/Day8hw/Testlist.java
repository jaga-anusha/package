package Day8hw;

import java.util.ArrayList;

public class Testlist {
	
	public static void main(String[] args) {
		
		ArrayList<String> name = new ArrayList<String>();
		
		name.add("sasi");
		name.add("super");
		System.out.println(name);
		
	}

}
