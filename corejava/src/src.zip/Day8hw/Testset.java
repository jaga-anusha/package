package Day8hw;

import java.util.LinkedHashSet;

public class Testset {
	
	public static void main(String[] args) {
		
		LinkedHashSet<String> students = new LinkedHashSet<String>();
		students.add("sasi");
		students.add("basi");
		students.add("jasi");
		students.add("vasi");
		System.out.println(students);
	}

}
