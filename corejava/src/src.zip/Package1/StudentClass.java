package Package1;

import Package2.AddressClass;

public class StudentClass {
	private String name;
	private AddressClass address;
	

	public AddressClass getAddress() {
		return address;
	}


	public void setAddress(AddressClass address2) {
		this.address = address2;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public void Method1(){
		
     
		
	}
}
