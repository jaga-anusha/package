package Package2;

public class AddressClass {
	
	private String line1;

	private String line2;
	
	private String getLine2() {
		return line2;
	}

	protected void setLine2(String line2) {
		this.line2 = line2;
	}

	public String getLine1() {
		return line1;
	}

	public void setLine1(String line1) {
		this.line1 = line1;
	}
	

	
}
