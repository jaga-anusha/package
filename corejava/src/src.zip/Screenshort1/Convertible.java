package Screenshort1;

public class Convertible extends SportsCar {
	public void dothings(){
		SportsCar sc = new SportsCar();
		sc.gofast();
	}
	public void domore(){
		gofast();
		
	}

}
