package Screenshort1;

public class Driver {
	public void dodriverstuff(){
		SportsCar car = new SportsCar();
		car.gofast();
		
		Convertible con = new Convertible();
		con.gofast();
	}

}
