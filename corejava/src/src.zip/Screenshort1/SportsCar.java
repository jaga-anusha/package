package Screenshort1;

public class SportsCar {
	
    public void gofast(){
    	
    }
    public void dostuff(){
    	gofast();
    	
    }
}
