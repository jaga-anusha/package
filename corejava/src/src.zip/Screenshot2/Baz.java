package Screenshot2;
import Selftest.Foo;

public class Baz {

	public static void main(String[] args) {
		Foo f = new Foo();
		//System.out.print(" " + f.a);
		//System.out.print(" " + f.b);
	    System.out.print(" " + f.c);
	 }
}
