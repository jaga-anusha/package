package Screenshot2;

public interface Bounceable {
	void bounce();
	void setBounceFactor(int bf);
	

}
