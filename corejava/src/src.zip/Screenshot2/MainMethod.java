package Screenshot2;

public class MainMethod {

	public static void main(String[] args) {
		
		Tire t =new Tire();
		t.bounce();
		
		
	}
	}


