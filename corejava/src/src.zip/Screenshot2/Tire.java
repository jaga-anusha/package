package Screenshot2;

public class Tire implements Bounceable {
	

	public void bounce(){
		System.out.println("my ball is bouncing");
	}
	public void setBounceFactor(int bf){
		System.out.println(3);
		
		
	}
}
