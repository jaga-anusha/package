package Selftest;

class Announce {
	public static void main(String[] args) {
	 for(int __x = 0; __x < 3; __x++) ;
	//int #lb = 7;
    //long [] x [5];
	Boolean []ba[];
	// enum Traffic { RED, YELLOW, GREEN };
	 }
}
