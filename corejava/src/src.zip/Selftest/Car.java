package Selftest;

public class Car extends Vehicle {
	
	public void mileage(){
		System.out.println("mileage was good");
	}
public void colour(){
	System.out.println("colour was black");
}
}
