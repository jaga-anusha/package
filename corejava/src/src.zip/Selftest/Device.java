package Selftest;

public interface Device {
	public void doIt();

}
