package Selftest;

public class Electronic implements Device
{	 public void doIt() { } }


