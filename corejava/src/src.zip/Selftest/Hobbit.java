package Selftest;

public class Hobbit {
	int countGold(int x, int y) { return x + y; }

}
