package Selftest;

public class Mainmethod {
public static void main(String[] args) {
	Vehicle v = new Vehicle();
	v.drive();
	Car c = new Car();
	c.colour();
	Subaru s = new Subaru();
	s.look();
	
	
}
}
