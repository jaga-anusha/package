package Selftest;

abstract class Phone1 extends Electronic {

}
