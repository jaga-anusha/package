package Selftest;

abstract class Phone2 extends Electronic {
	 public void doIt(int x) { }

}
