package Selftest;
 class Phone3 extends Electronic implements Device {
	 public void doStuff() { } 

}
