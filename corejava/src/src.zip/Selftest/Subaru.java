package Selftest;

public class Subaru extends Car {

	public void enginemodel(){
		System.out.println("latest model in market");
	}
	public void look(){
		System.out.println("good looking in market");
	}
}
