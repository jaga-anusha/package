package Selftest;

public class Vehicle {
	
public void drive(){
	System.out.println("drive method is invoked");
}
public void stop(){
	System.out.println("stop method is invoked");
}
}

	
