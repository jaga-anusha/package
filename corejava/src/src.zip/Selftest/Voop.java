package Selftest;
public class Voop {

		 public static void main(String[] args) {
		 //doStuff(1);
		 //doStuff(1,2);
		 }
		 //static void doStuff(int... doArgs) { }
		 //static void doStuff(int[] doArgs) { }
		 //static void doStuff(int doArgs...) { }
		 //static void doStuff(int... doArgs, int y) { }
		 //static void doStuff(int x, int... doArgs) { }
		 // insert code here

		
			
		}
	 

