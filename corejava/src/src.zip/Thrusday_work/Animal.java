package Thrusday_work;

public class Animal {

	public Animal(){
		super();
		System.out.println("1.Animal is Getting Consttructed");
	}
	public void add(int i){
		System.out.println("hiello");
	}

	
}
