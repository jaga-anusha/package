package Thrusday_work;

public class Horse extends Animal {
	
	public Horse(){
		super();
		System.out.println("2. Horse is Getting Consttructed");
	}
	public Horse(String name){
		this();
		System.out.println("3. Overloaded default constructor is called");
		
		
	}
	
	

}
