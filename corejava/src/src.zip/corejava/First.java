package corejava;

public class First {
	
int s;
{
System.out.println(s);
}
	public static void main(String args[]){
		int a = 10;
		int b=20;
		int c=30 ;
		int d = a+b+c;
		int e = c-(a+b);
		int f = a*b*c;
		int g = b/a;
		int h =b%a;
		
		System.out.println(h);
		System.out.println(g);
		System.out.println(f);
		System.out.println(e);
		System.out.println(d);
		
	}
}
